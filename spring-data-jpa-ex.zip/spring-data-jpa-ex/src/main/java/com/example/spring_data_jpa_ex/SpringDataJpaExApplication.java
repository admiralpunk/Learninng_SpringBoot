package com.example.spring_data_jpa_ex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaExApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaExApplication.class, args);
	}

}
